/* Here's a file with no contents to try */
