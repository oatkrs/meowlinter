
// Ensure reference to boost::system is ignored

void HandleWrite(const boost::system::error_code &error);
